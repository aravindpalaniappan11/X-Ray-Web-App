# from django import forms
# from .models import Patient

# # class PatientForm(forms.ModelForm):
# #     class Meta:
# #         model = Patient
# #         fields = ['name', 'gender', 'dob', 'image']

# GENDER_CHOICES = [
#     ('male', 'Male'),
#     ('female', 'Female'),
#     ('other', 'Other'),
# ]

# class PatientForm(forms.Form):
#     name = forms.CharField(max_length=100)
#     gender = forms.ChoiceField(choices=GENDER_CHOICES)
#     dob = forms.DateField()
#     image = forms.ImageField()

# from django import forms
# from django.contrib.admin import widgets

# class PatientForm(forms.Form):
#     name = forms.CharField(max_length=100)
#     gender = forms.ChoiceField(choices=[
#         ('Male', 'Male'),
#         ('Female', 'Female'),
#         ('Retards', 'Retards'),
#     ])
#     dob = forms.DateField(
#         widget=widgets.AdminDateWidget(attrs={'type': 'date'}),
#         required=True
#     )
#     image = forms.ImageField()

from django import forms
from .models import Patient

class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = ['name', 'gender', 'dob', 'image']
        widgets = {
            'dob': forms.DateInput(attrs={'type': 'date'}),
        }