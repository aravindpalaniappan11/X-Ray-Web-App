import os
import tensorflow as tf

def get_models():
    # Get the current working directory
    current_dir = os.getcwd()

    # Construct the full path to the models folder
    models_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'models')

    # Load all the trained models
    models = [
        tf.keras.models.load_model(os.path.join(models_dir, 'resnet50_finetuned_best.h5')),
        tf.keras.models.load_model(os.path.join(models_dir, 'vgg19_finetuned_best.h5')),
        tf.keras.models.load_model(os.path.join(models_dir, 'densenet121_finetuned_best.h5')),
        tf.keras.models.load_model(os.path.join(models_dir, 'mobilenetv2_finetuned_best.h5')),
        tf.keras.models.load_model(os.path.join(models_dir, 'inceptionv3_finetuned_best.h5'))
    ]

    return models

import cv2
import numpy as np

def preprocess_single_image(image_path):
    img = cv2.imread(image_path, cv2.IMREAD_GRAYSCALE)
    if img is None:
        print(f"Warning: file {image_path} could not be read, skipping.")
        return None
    img_blur = cv2.GaussianBlur(img, (5, 5), 0)
    img_equalized = cv2.equalizeHist(img_blur)
    img_resized = cv2.resize(img_equalized, (224, 224))
    img_rgb = cv2.cvtColor(img_resized, cv2.COLOR_GRAY2RGB)
    img_array = np.expand_dims(img_rgb, axis=0)
    img_array = img_array.astype('float32') / 255.0
    return img_array

def ensemble_predict_single_image(models, image_array):
    ensemble_predictions = []
    for model in models:
        predictions = model.predict(image_array)
        ensemble_predictions.append(predictions)
    ensemble_predictions = np.mean(ensemble_predictions, axis=0)
    ensemble_class_index = np.argmax(ensemble_predictions, axis=1)[0]
    return ensemble_class_index

__all__ = ['preprocess_single_image', 'ensemble_predict_single_image', 'get_models']
