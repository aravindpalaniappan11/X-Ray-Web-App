# from django.db import models

# class Patient(models.Model):
#     name = models.CharField(max_length=100)
#     gender = models.CharField(max_length=10)
#     dob = models.DateField()
#     image = models.ImageField(upload_to='patient_images/')

from django.db import models

class Patient(models.Model):
    name = models.CharField(max_length=100)
    gender = models.CharField(max_length=10, choices=[
        ('Male', 'Male'),
        ('Female', 'Female'),
        ('Retards', 'Retards'),
    ])
    dob = models.DateField()
    image = models.ImageField(upload_to='patient_images/')