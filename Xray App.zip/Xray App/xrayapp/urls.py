# gymapp/urls.py
from django.urls import path
from . import views

app_name = 'xrayapp'

urlpatterns = [
    path('', views.index, name='index/root'),
    path('index.html', views.index, name='index_html'),
    path('patient_form.html', views.patient_form_view, name ='patient_form'),
    path('report/<int:patient_id>/', views.report_view, name='report_view'),

]
