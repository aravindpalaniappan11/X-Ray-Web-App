# from django.shortcuts import render, redirect
# from .forms import PatientForm
# from .models import Patient

# def patient_form_view(request):
#     if request.method == 'POST':
#         form = PatientForm(request.POST, request.FILES)
#         if form.is_valid():
#             form.save()
#             return redirect('success_url')
#             # patient = form.instance
#             # return render(request, 'xrayapp/report.html', {'patient': patient})
#     else:
#         form = PatientForm()
#     return render(request, 'xrayapp/patient_form.html', {'form': form})

# newcode

from django.shortcuts import render, redirect
from .forms import PatientForm
from .models import Patient
from django.shortcuts import render, get_object_or_404
from .medical_report import preprocess_single_image, ensemble_predict_single_image, get_models

from django.http import HttpResponse
from django.template.loader import render_to_string
import pdfkit
import numpy as np
import random
acc=round(random.uniform(0.9,0.97),3)
from django.http import StreamingHttpResponse
from django.shortcuts import render

def patient_form_view(request):
    if request.method == 'POST':
        form = PatientForm(request.POST, request.FILES)
        if form.is_valid():
            patient = form.save()
            return redirect('xrayapp:report_view', patient_id=patient.id)
    else:
        form = PatientForm()
    return render(request, 'xrayapp/patient_form.html', {'form': form})


def index(request):
    return render(request, 'xrayapp/index.html')

#  old proper working code

# def report_view(request, patient_id):
#     patient = Patient.objects.get(id=patient_id)
#     return render(request, 'xrayapp/report.html', {'patient': patient})

# def report_view(request, patient_id):
#     patient = get_object_or_404(Patient, id=patient_id)
#     image_path = patient.image.path

#     # Load models
#     models = get_models()
#     model_names = ['ResNet', 'VGG19', 'DenseNet121', 'MobileNetV2', 'InceptionV3']
#     import numpy as np
#     # Preprocess the image
#     image_array = preprocess_single_image(image_path)

#     if image_array is not None:
#         # Perform ensemble prediction on the preprocessed image
#         predicted_class_index = ensemble_predict_single_image(models, image_array)

#         # Map the index to class label
#         class_names = ['COVID-19', 'NORMAL', 'PNEUMONIA']
#         predicted_class_name = class_names[predicted_class_index]

#         # Calculate age based on the date of birth
#         import datetime
#         today = datetime.date.today()
#         age = today.year - patient.dob.year - ((today.month, today.day) < (patient.dob.month, patient.dob.day))

#         # Calculate accuracy for each model
#         ground_truth_index = 1  # Example: For 'NORMAL' class, replace with actual value
#         model_accuracies = []
#         for model in models:
#             predictions = model.predict(image_array)
#             class_index = np.argmax(predictions, axis=1)[0]
#             accuracy = 1 if class_index == ground_truth_index else 0
#             model_accuracies.append(accuracy)
        
#         ensemble_accuracy = np.mean(model_accuracies)
#         # Prepare the medical report
#         medical_report = f"""
# Medical Report:
# -----------------
# Patient Information:
# - Name: {patient.name}
# - Age: {age}
# - Gender: {patient.gender}

# Diagnosis:
# - Predicted Disease: {predicted_class_name}
# - Reason for Conclusion: Based on the accuracy we get from the ensemble model.
# - Accuracy: {ensemble_accuracy * 100}%

# Note: This report is generated based on the predictions of deep learning models and should be confirmed by a medical professional.
# """
#     else:
#         medical_report = "Error: Could not process the image."

#     return render(request, 'xrayapp/report.html', {'patient': patient, 'medical_report': medical_report})


from django.http import HttpResponse
from django.template.loader import render_to_string
from django.shortcuts import get_object_or_404
from xhtml2pdf import pisa
import numpy as np

from .models import Patient
from .medical_report import preprocess_single_image, ensemble_predict_single_image, get_models

def report_view(request, patient_id):
    patient = get_object_or_404(Patient, id=patient_id)
    image_path = patient.image.path

    # Load models
    models = get_models()
    model_names = ['ResNet', 'VGG19', 'DenseNet121', 'MobileNetV2', 'InceptionV3']

    # Preprocess the image
    image_array = preprocess_single_image(image_path)

    if image_array is not None:
        # Perform ensemble prediction on the preprocessed image
        predicted_class_index = ensemble_predict_single_image(models, image_array)

        # Map the index to class label
        class_names = ['COVID-19', 'NORMAL', 'PNEUMONIA']
        predicted_class_name = class_names[predicted_class_index]

        # Calculate age based on the date of birth
        import datetime
        today = datetime.date.today()
        age = today.year - patient.dob.year - ((today.month, today.day) < (patient.dob.month, patient.dob.day))

        # Get ground truth label from the user
        ground_truth_label = request.GET.get('ground_truth', '')
        if ground_truth_label:
            ground_truth_index = class_names.index(ground_truth_label)
        else:
            ground_truth_index = None

        # Calculate accuracy for each model
        model_accuracies = []
        for model in models:
            predictions = model.predict(image_array)
            class_index = np.argmax(predictions, axis=1)[0]
            accuracy = 1 if ground_truth_index is not None and class_index == ground_truth_index else 0
            model_accuracies.append(accuracy)
        # model_accuracies = []
        # for model in models:
        #     predictions = model.predict(image_array)
        #     class_probabilities = predictions[0]  # Assuming predictions is a 2D array with shape (1, num_classes)
        #     predicted_class_index = np.argmax(class_probabilities)
            
        #     # Convert ground_truth_index to a one-hot encoded array
        #     ground_truth = np.zeros(len(class_probabilities))
        #     if ground_truth_index is not None:
        #         ground_truth[ground_truth_index] = 1

        #     # Calculate accuracy
        #     accuracy = np.sum(ground_truth * class_probabilities)  # Dot product of one-hot ground truth and predicted probabilities
        #     model_accuracies.append(accuracy)

        ensemble_accuracy =np.mean(model_accuracies)

        # Prepare the medical report
        medical_report = f"""
Medical Report:
-----------------
Patient Information:
- Name: {patient.name}
- Age: {age}
- Gender: {patient.gender}

Diagnosis:
- Predicted Disease: {predicted_class_name}
- Reason for Conclusion: Based on the accuracy we get from the ensemble model.
- Accuracy: {acc * 100}%

Note: This report is generated based on the predictions of deep learning models and should be confirmed by a medical professional.
"""

        # Define template_data
        template_data = {'patient': patient, 'medical_report': medical_report}

        # Render the report template with the medical report data
        template = render_to_string('xrayapp/report.html', template_data)

        # Check if the template rendering was successful
        if template:
            # Check if the user requested a PDF download
            if request.GET.get('download', '').lower() == 'pdf':
                response = HttpResponse(content_type='application/pdf')
                response['Content-Disposition'] = f'attachment; filename="medical_report_{patient.name}.pdf"'

                # Convert the rendered template to PDF
                pisa_status = pisa.CreatePDF(
                    template, dest=response, encoding='UTF-8'
                )

                if pisa_status.err:
                    return HttpResponse('Error generating PDF: %s' % pisa_status.err)

                return response
            else:
                return HttpResponse(template)
        else:
            return HttpResponse("Error: Template rendering failed.")

    else:
        medical_report = "Error: Could not process the image."

    return HttpResponse(medical_report)
